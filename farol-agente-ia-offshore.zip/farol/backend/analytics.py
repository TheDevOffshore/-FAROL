"""
FAROL — Engine de análise (as "ferramentas" do agente).

Cada função é uma ferramenta determinística sobre os dados reais.
O LLM nunca calcula números: ele escolhe a ferramenta, a engine responde.
Isso elimina alucinação numérica — princípio central do projeto.
"""
from pathlib import Path

import pandas as pd

DATA_DIR = Path(__file__).resolve().parent.parent / "data"


class Analytics:
    def __init__(self):
        self.flights = pd.read_csv(DATA_DIR / "flights.csv", parse_dates=["date"])
        self.weather = pd.read_csv(DATA_DIR / "weather.csv", parse_dates=["date"])
        self.maintenance = pd.read_csv(DATA_DIR / "maintenance.csv", parse_dates=["date"])

    # ------------------------------------------------------------------ tools
    def kpis(self, platform: str | None = None, basin: str | None = None) -> dict:
        """KPIs gerais: total de voos, horas, taxa de aborto, disponibilidade."""
        df = self._filter(self.flights, platform, basin)
        total = len(df)
        aborted = int((df.status == "ABORTADO").sum())
        return {
            "total_voos": total,
            "horas_voo": round(df.duration_min.sum() / 60, 1),
            "voos_abortados": aborted,
            "taxa_aborto_pct": round(100 * aborted / max(total, 1), 2),
            "duracao_media_min": round(df.duration_min.mean(), 1),
            "saude_media_bateria_pct": round(df.battery_health_pct.mean(), 1),
        }

    def flights_by_month(self, platform: str | None = None) -> dict:
        """Série mensal de voos concluídos vs abortados (para gráfico)."""
        df = self._filter(self.flights, platform)
        g = df.groupby([df.date.dt.to_period("M").astype(str), "status"]).size().unstack(fill_value=0)
        return {
            "labels": list(g.index),
            "concluidos": [int(x) for x in g.get("CONCLUÍDO", pd.Series(0, index=g.index))],
            "abortados": [int(x) for x in g.get("ABORTADO", pd.Series(0, index=g.index))],
        }

    def abort_analysis(self, platform: str | None = None) -> dict:
        """Causas de aborto e correlação com rajada de vento."""
        df = self._filter(self.flights, platform)
        ab = df[df.status == "ABORTADO"]
        reasons = ab.abort_reason.value_counts().to_dict()
        # taxa de aborto por faixa de rajada
        bins = pd.cut(df.max_gust_kt, [0, 15, 20, 25, 30, 100],
                      labels=["<15 kt", "15–20 kt", "20–25 kt", "25–30 kt", ">30 kt"])
        rate = df.groupby(bins, observed=True).apply(
            lambda g: round(100 * (g.status == "ABORTADO").mean(), 1), include_groups=False)
        return {"causas": {k: int(v) for k, v in reasons.items()},
                "taxa_por_rajada": {str(k): float(v) for k, v in rate.items()}}

    def fleet_health(self) -> dict:
        """Saúde de bateria e ciclos por aeronave + custo de manutenção."""
        last = self.flights.sort_values("date").groupby("aircraft").tail(1)
        maint = self.maintenance.groupby("aircraft").agg(
            eventos=("type", "count"), custo_total_brl=("cost_brl", "sum"),
            downtime_h=("downtime_h", "sum")).round(1)
        out = {}
        for _, r in last.iterrows():
            m = maint.loc[r.aircraft] if r.aircraft in maint.index else None
            out[r.aircraft] = {
                "modelo": r.model,
                "saude_bateria_pct": float(r.battery_health_pct),
                "ciclos_bateria": int(r.battery_cycles),
                "eventos_manutencao": int(m.eventos) if m is not None else 0,
                "custo_manutencao_brl": float(m.custo_total_brl) if m is not None else 0.0,
                "downtime_h": float(m.downtime_h) if m is not None else 0.0,
            }
        return out

    def weather_summary(self, platform: str | None = None, basin: str | None = None) -> dict:
        """Resumo meteorológico mensal: vento médio e rajada máxima."""
        df = self._filter(self.weather, platform, basin)
        g = df.groupby(df.date.dt.to_period("M").astype(str)).agg(
            vento_medio_kt=("wind_avg_kt", "mean"), rajada_max_kt=("gust_max_kt", "max")).round(1)
        return {"labels": list(g.index),
                "vento_medio_kt": list(g.vento_medio_kt),
                "rajada_max_kt": list(g.rajada_max_kt)}

    def compare_platforms(self) -> dict:
        """Comparativo de KPIs entre todas as plataformas."""
        return {p: self.kpis(platform=p) for p in sorted(self.flights.platform.unique())}

    # ---------------------------------------------------------------- helpers
    def _filter(self, df, platform=None, basin=None):
        if platform:
            df = df[df.platform.str.upper() == platform.upper()]
        if basin:
            df = df[df.basin.str.lower() == basin.lower()]
        return df


TOOL_SPECS = [
    {"name": "kpis", "description": "KPIs gerais de operação (voos, horas, taxa de aborto, bateria). Aceita filtro opcional por plataforma (P-74, P-66, PCH-1, PNA-2) ou bacia (Santos, Campos).",
     "input_schema": {"type": "object", "properties": {
         "platform": {"type": "string"}, "basin": {"type": "string"}}}},
    {"name": "flights_by_month", "description": "Série temporal mensal de voos concluídos vs abortados. Filtro opcional por plataforma.",
     "input_schema": {"type": "object", "properties": {"platform": {"type": "string"}}}},
    {"name": "abort_analysis", "description": "Causas de aborto de missão e taxa de aborto por faixa de rajada de vento. Filtro opcional por plataforma.",
     "input_schema": {"type": "object", "properties": {"platform": {"type": "string"}}}},
    {"name": "fleet_health", "description": "Saúde de bateria, ciclos, custo e downtime de manutenção por aeronave da frota.",
     "input_schema": {"type": "object", "properties": {}}},
    {"name": "weather_summary", "description": "Resumo meteorológico mensal (vento médio e rajada máxima). Filtros opcionais por plataforma ou bacia.",
     "input_schema": {"type": "object", "properties": {
         "platform": {"type": "string"}, "basin": {"type": "string"}}}},
    {"name": "compare_platforms", "description": "Comparativo de KPIs entre todas as plataformas.",
     "input_schema": {"type": "object", "properties": {}}},
]
