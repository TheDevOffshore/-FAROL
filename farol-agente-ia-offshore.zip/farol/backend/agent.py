"""
FAROL — Agente de IA com tool-calling.

Fluxo:
  pergunta em linguagem natural
    → Claude escolhe a ferramenta (analytics.py)
    → engine pandas calcula sobre os dados reais
    → Claude redige a resposta citando os números retornados

Sem ANTHROPIC_API_KEY o sistema cai em modo OFFLINE: um roteador
por palavras-chave escolhe a ferramenta e a resposta é gerada por
template. A demo funciona 100% sem custo — o LLM é um upgrade.
"""
import json
import os
import re

from analytics import Analytics, TOOL_SPECS

SYSTEM_PROMPT = """Você é o FAROL, agente de análise de operações RPAS offshore.
Responda SEMPRE em português brasileiro, de forma direta e profissional.
Use as ferramentas para obter números reais — nunca invente valores.
Cite os números exatos retornados pelas ferramentas. Quando fizer sentido,
feche com uma recomendação operacional curta (1 frase)."""

API_URL = "https://api.anthropic.com/v1/messages"
MODEL = "claude-sonnet-4-6"


class Agent:
    def __init__(self):
        self.analytics = Analytics()
        self.api_key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
        self.online = bool(self.api_key)

    def ask(self, question: str) -> dict:
        if self.online:
            try:
                return self._ask_llm(question)
            except Exception as e:  # rede/quota → degrada com elegância
                out = self._ask_offline(question)
                out["mode"] = f"offline (fallback: {type(e).__name__})"
                return out
        return self._ask_offline(question)

    # ------------------------------------------------------------- LLM mode
    def _ask_llm(self, question: str) -> dict:
        import urllib.request

        messages = [{"role": "user", "content": question}]
        tool_payload = None
        for _ in range(4):  # até 4 rodadas de tool use
            body = json.dumps({
                "model": MODEL, "max_tokens": 1024, "system": SYSTEM_PROMPT,
                "messages": messages, "tools": TOOL_SPECS,
            }).encode()
            req = urllib.request.Request(API_URL, data=body, headers={
                "content-type": "application/json",
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01"})
            with urllib.request.urlopen(req, timeout=60) as r:
                resp = json.loads(r.read())

            tool_uses = [b for b in resp["content"] if b["type"] == "tool_use"]
            if not tool_uses:
                text = "".join(b.get("text", "") for b in resp["content"])
                return {"answer": text, "tool": tool_payload, "mode": "llm"}

            messages.append({"role": "assistant", "content": resp["content"]})
            results = []
            for tu in tool_uses:
                data = self._run_tool(tu["name"], tu.get("input", {}))
                tool_payload = {"name": tu["name"], "data": data}
                results.append({"type": "tool_result", "tool_use_id": tu["id"],
                                "content": json.dumps(data, ensure_ascii=False)})
            messages.append({"role": "user", "content": results})
        return {"answer": "Não consegui concluir a análise.", "tool": tool_payload, "mode": "llm"}

    # --------------------------------------------------------- offline mode
    ROUTES = [
        (r"compar|melhor plataforma|ranking", "compare_platforms"),
        (r"abort|cancel|rajada|vento.*(limite|risco)|causa", "abort_analysis"),
        (r"frota|bateria|manuten|aeronave|drone|custo|saúde|saude", "fleet_health"),
        (r"meteo|clima|vento|tempo", "weather_summary"),
        (r"m[eê]s|mensal|evolu|tend[eê]ncia|hist[óo]rico", "flights_by_month"),
    ]

    def _ask_offline(self, question: str) -> dict:
        q = question.lower()
        tool = "kpis"
        for pattern, name in self.ROUTES:
            if re.search(pattern, q):
                tool = name
                break
        args = {}
        m = re.search(r"(p-?74|p-?66|pch-?1|pna-?2)", q)
        if m and tool in ("kpis", "flights_by_month", "abort_analysis", "weather_summary"):
            args["platform"] = m.group(1).upper().replace("P74", "P-74").replace("P66", "P-66") \
                .replace("PCH1", "PCH-1").replace("PNA2", "PNA-2")
        for basin in ("santos", "campos"):
            if basin in q and tool in ("kpis", "weather_summary"):
                args["basin"] = basin.capitalize()
        data = self._run_tool(tool, args)
        return {"answer": self._template(tool, args, data),
                "tool": {"name": tool, "data": data}, "mode": "offline"}

    def _template(self, tool, args, d) -> str:
        scope = f" em {args['platform']}" if args.get("platform") else (
            f" na bacia de {args['basin']}" if args.get("basin") else "")
        if tool == "kpis":
            return (f"Resumo operacional{scope}: {d['total_voos']} voos e {d['horas_voo']} h de voo. "
                    f"Taxa de aborto de {d['taxa_aborto_pct']}% ({d['voos_abortados']} missões). "
                    f"Duração média de {d['duracao_media_min']} min e saúde média de bateria em "
                    f"{d['saude_media_bateria_pct']}%.")
        if tool == "abort_analysis":
            top = max(d["causas"], key=d["causas"].get)
            worst = max(d["taxa_por_rajada"], key=d["taxa_por_rajada"].get)
            return (f"Análise de abortos{scope}: principal causa é \"{top}\" "
                    f"({d['causas'][top]} ocorrências). A taxa de aborto cresce com a rajada, "
                    f"chegando a {d['taxa_por_rajada'][worst]}% na faixa {worst}. "
                    f"Recomendação: reforçar o critério GO/NO-GO acima de 22 kt.")
        if tool == "fleet_health":
            worst = min(d, key=lambda k: d[k]["saude_bateria_pct"])
            w = d[worst]
            return (f"Saúde da frota: a aeronave mais desgastada é a {worst} ({w['modelo']}), com "
                    f"{w['saude_bateria_pct']}% de saúde de bateria após {w['ciclos_bateria']} ciclos, "
                    f"R$ {w['custo_manutencao_brl']:,.2f} em manutenção e {w['downtime_h']} h de downtime. "
                    f"Recomendação: planejar substituição de baterias dessa aeronave.")
        if tool == "weather_summary":
            i = d["rajada_max_kt"].index(max(d["rajada_max_kt"]))
            return (f"Meteorologia{scope}: pior mês foi {d['labels'][i]}, com rajada máxima de "
                    f"{d['rajada_max_kt'][i]} kt. Vento médio recente: {d['vento_medio_kt'][-1]} kt.")
        if tool == "flights_by_month":
            return (f"Evolução mensal{scope}: último mês com {d['concluidos'][-1]} voos concluídos e "
                    f"{d['abortados'][-1]} abortados, de um histórico de {len(d['labels'])} meses.")
        if tool == "compare_platforms":
            best = min(d, key=lambda k: d[k]["taxa_aborto_pct"])
            worst = max(d, key=lambda k: d[k]["taxa_aborto_pct"])
            return (f"Comparativo: melhor confiabilidade em {best} "
                    f"({d[best]['taxa_aborto_pct']}% de aborto) e pior em {worst} "
                    f"({d[worst]['taxa_aborto_pct']}%). Veja o detalhamento no painel.")
        return "Análise concluída — veja os dados no painel."

    def _run_tool(self, name: str, args: dict):
        fn = getattr(self.analytics, name)
        return fn(**{k: v for k, v in args.items() if v})
