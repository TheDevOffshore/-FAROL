"""FAROL — API FastAPI. Serve o front e expõe o agente + endpoints diretos."""
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from pydantic import BaseModel

from agent import Agent
from analytics import Analytics

app = FastAPI(title="FAROL — Agente de Análise Operacional Offshore", version="1.0.0")
agent = Agent()
analytics = Analytics()
FRONT = Path(__file__).resolve().parent.parent / "frontend" / "index.html"


class Question(BaseModel):
    question: str


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(FRONT)


@app.get("/api/status")
def status():
    return {"online_llm": agent.online,
            "mode": "Claude API (tool-calling)" if agent.online else "Offline (roteador local)"}


@app.post("/api/ask")
def ask(q: Question):
    return agent.ask(q.question.strip()[:500])


# Endpoints diretos (úteis para o dashboard e para mostrar a API no portfólio)
@app.get("/api/kpis")
def kpis(platform: str | None = None, basin: str | None = None):
    return analytics.kpis(platform, basin)


@app.get("/api/flights/monthly")
def monthly(platform: str | None = None):
    return analytics.flights_by_month(platform)


@app.get("/api/aborts")
def aborts(platform: str | None = None):
    return analytics.abort_analysis(platform)


@app.get("/api/fleet")
def fleet():
    return analytics.fleet_health()


@app.get("/api/weather")
def weather(platform: str | None = None, basin: str | None = None):
    return analytics.weather_summary(platform, basin)
