"""
FAROL — Gerador de dados operacionais sintéticos (porém realistas).

Gera 18 meses de operação RPAS offshore em 4 plataformas das bacias de
Campos e Santos: logs de voo, meteorologia horária e eventos de manutenção.

Os dados seguem padrões reais do domínio:
- Vento mais forte no inverno (jun-ago) nas duas bacias
- Degradação de bateria por ciclos de carga
- Taxa de aborto de missão correlacionada com rajadas > 22 kt
"""
import math
import random
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

random.seed(42)

DATA_DIR = Path(__file__).resolve().parent.parent / "data"

PLATFORMS = [
    {"id": "P-74", "basin": "Santos", "lat": -25.45, "lon": -42.85},
    {"id": "P-66", "basin": "Santos", "lat": -25.10, "lon": -43.20},
    {"id": "PCH-1", "basin": "Campos", "lat": -22.50, "lon": -40.05},
    {"id": "PNA-2", "basin": "Campos", "lat": -22.20, "lon": -40.30},
]

AIRCRAFT = [
    {"id": "M300-01", "model": "DJI M300 RTK"},
    {"id": "M300-02", "model": "DJI M300 RTK"},
    {"id": "M30T-01", "model": "DJI M30T"},
    {"id": "M350-01", "model": "DJI M350 RTK"},
]

MISSION_TYPES = ["Inspeção de flare", "Inspeção estrutural", "Monitoramento ambiental",
                 "Apoio a içamento", "Inspeção de riser", "Vigilância de área"]

ABORT_REASONS = ["Rajada acima do limite", "Falha de link RTK", "Bateria abaixo do mínimo",
                 "Tráfego de helicóptero", "Chuva repentina", "Interferência eletromagnética"]


def wind_for(date: datetime, basin: str) -> float:
    """Vento médio (kt) com sazonalidade de inverno + ruído."""
    season = math.cos((date.timetuple().tm_yday - 200) / 365 * 2 * math.pi)  # pico ~jul
    base = 14 + 4 * season + (1.5 if basin == "Santos" else 0)
    return max(3, random.gauss(base, 4.5))


def generate(months: int = 18):
    DATA_DIR.mkdir(exist_ok=True)
    start = datetime(2025, 1, 1)
    end = start + timedelta(days=int(months * 30.4))

    # --- Meteorologia diária por plataforma ---
    weather_rows = []
    day = start
    while day < end:
        for p in PLATFORMS:
            wind = wind_for(day, p["basin"])
            gust = wind + abs(random.gauss(4, 2.5))
            weather_rows.append({
                "date": day.date().isoformat(),
                "platform": p["id"],
                "basin": p["basin"],
                "wind_avg_kt": round(wind, 1),
                "gust_max_kt": round(gust, 1),
                "rain_mm": round(max(0, random.gauss(2, 5)), 1),
                "visibility_km": round(min(20, max(0.5, random.gauss(12, 4))), 1),
            })
        day += timedelta(days=1)
    weather = pd.DataFrame(weather_rows)
    weather.to_csv(DATA_DIR / "weather.csv", index=False)

    # --- Voos ---
    flight_rows = []
    battery_cycles = {a["id"]: random.randint(40, 90) for a in AIRCRAFT}
    fid = 1000
    day = start
    while day < end:
        for p in PLATFORMS:
            w = weather[(weather.date == day.date().isoformat()) & (weather.platform == p["id"])].iloc[0]
            n_flights = random.choice([0, 1, 1, 2, 2, 3]) if w.gust_max_kt < 30 else random.choice([0, 0, 1])
            for _ in range(n_flights):
                ac = random.choice(AIRCRAFT)
                battery_cycles[ac["id"]] += 1
                cycles = battery_cycles[ac["id"]]
                battery_health = max(70, 100 - cycles * 0.045 - random.uniform(0, 2))
                gust_now = w.gust_max_kt * random.uniform(0.75, 1.0)
                abort_p = 0.04 + max(0, (gust_now - 22) * 0.045) + max(0, (88 - battery_health) * 0.01)
                aborted = random.random() < abort_p
                duration = random.uniform(4, 9) if aborted else random.uniform(18, 38)
                fid += 1
                flight_rows.append({
                    "flight_id": f"F{fid}",
                    "date": day.date().isoformat(),
                    "platform": p["id"],
                    "basin": p["basin"],
                    "aircraft": ac["id"],
                    "model": ac["model"],
                    "mission_type": random.choice(MISSION_TYPES),
                    "duration_min": round(duration, 1),
                    "max_gust_kt": round(gust_now, 1),
                    "battery_health_pct": round(battery_health, 1),
                    "battery_cycles": cycles,
                    "status": "ABORTADO" if aborted else "CONCLUÍDO",
                    "abort_reason": random.choice(ABORT_REASONS) if aborted else "",
                })
        day += timedelta(days=1)
    flights = pd.DataFrame(flight_rows)
    flights.to_csv(DATA_DIR / "flights.csv", index=False)

    # --- Manutenção ---
    maint_rows = []
    for ac in AIRCRAFT:
        d = start + timedelta(days=random.randint(5, 40))
        while d < end:
            kind = random.choices(
                ["Preventiva programada", "Troca de hélices", "Calibração IMU/RTK",
                 "Substituição de bateria", "Corretiva não programada"],
                weights=[40, 20, 15, 12, 13])[0]
            maint_rows.append({
                "date": d.date().isoformat(),
                "aircraft": ac["id"],
                "type": kind,
                "downtime_h": round(random.uniform(1, 30 if "Corretiva" in kind else 8), 1),
                "cost_brl": round(random.uniform(300, 9000 if "Corretiva" in kind else 2500), 2),
            })
            d += timedelta(days=random.randint(18, 50))
    pd.DataFrame(maint_rows).to_csv(DATA_DIR / "maintenance.csv", index=False)

    print(f"OK: {len(flights)} voos, {len(weather)} registros meteo, {len(maint_rows)} manutenções")


if __name__ == "__main__":
    generate()
